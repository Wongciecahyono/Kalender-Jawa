import React, { useState, useEffect } from 'react';
import { Calendar, Calculator, Settings, Google, ChevronLeft, ChevronRight, Info } from 'lucide-react';

const CalendarJawaApp = () => {
  // ============ NEPTU & PASARAN DATA ============
  const NEPTU_HARI = {
    0: { name: 'Ahad', neptu: 5 },
    1: { name: 'Senen', neptu: 4 },
    2: { name: 'Selasa', neptu: 3 },
    3: { name: 'Rabu', neptu: 7 },
    4: { name: 'Kamis', neptu: 8 },
    5: { name: 'Jumat', neptu: 6 },
    6: { name: 'Sabtu', neptu: 9 }
  };

  const PASARAN = ['Legi', 'Pahing', 'Pon', 'Wage', 'Kliwon'];
  const PASARAN_NEPTU = { 'Legi': 5, 'Pahing': 9, 'Pon': 7, 'Wage': 4, 'Kliwon': 8 };

  const WUKU = [
    'Sungsang', 'Langkir', 'Mangir', 'Sumber', 'Wastu', 'Gumbreg', 'Warigalit', 'Warijathil',
    'Tolu', 'Gajamina', 'Kurantil', 'Salahunan', 'Gentini', 'Lintang', 'Pandhawa', 'Pandawa',
    'Wulanhayu', 'Madangkungan', 'Mahameru', 'Pawukon', 'Kumba', 'Labuagu', 'Karangbitu', 'Saptamangsa',
    'Sagapenjalin', 'Kampakeningpati', 'Sungsang', 'Langkir', 'Mangir', 'Sumber'
  ];

  const NETON_HASIL = {
    1: { name: 'Mati', type: 'jelek', artinya: 'Tidak baik, hindari' },
    2: { name: 'Kekayaan/Jodoh', type: 'bagus', artinya: 'Baik untuk urusan pernikahan & usaha' },
    3: { name: 'Selamat/Bertolak belakang', type: 'sedang', artinya: 'Cukup baik tergantung konteks' },
    4: { name: 'Cerai/Kehilangan', type: 'jelek', artinya: 'Tidak baik, hindari' },
    5: { name: 'Prihatin/Kehormatan', type: 'sedang', artinya: 'Perlu pertimbangan matang' },
    6: { name: 'Lancar', type: 'bagus', artinya: 'Baik untuk segala urusan' },
    7: { name: 'Pegat/Putus', type: 'jelek', artinya: 'Tidak baik, hindari' }
  };

  // ============ STATE ============
  const [currentDate, setCurrentDate] = useState(new Date());
  const [activeTab, setActiveTab] = useState('calendar');
  const [googleConnected, setGoogleConnected] = useState(false);
  const [calculatorDate, setCalculatorDate] = useState(new Date());

  // ============ KALENDER JAWA FUNCTIONS ============
  
  const getPasaran = (date) => {
    const epochDate = new Date(1900, 0, 1);
    const diffTime = Math.abs(date - epochDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const pasaranIndex = diffDays % 5;
    return PASARAN[pasaranIndex];
  };

  const getWuku = (date) => {
    const epochDate = new Date(1900, 0, 1);
    const diffTime = Math.abs(date - epochDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const wukuIndex = (diffDays / 7) % 30;
    return WUKU[Math.floor(wukuIndex)];
  };

  const getNeptu = (date) => {
    const dayIndex = date.getDay();
    const pasaran = getPasaran(date);
    const hariNeptu = NEPTU_HARI[dayIndex].neptu;
    const pasaranNeptu = PASARAN_NEPTU[pasaran];
    return hariNeptu + pasaranNeptu;
  };

  const getNeton = (date) => {
    const neptu = getNeptu(date);
    const hasil = ((neptu - 1) % 7) + 1;
    return hasil;
  };

  const getWeton = (date) => {
    const dayIndex = date.getDay();
    const hariName = NEPTU_HARI[dayIndex].name;
    const pasaran = getPasaran(date);
    return `${hariName} ${pasaran}`;
  };

  // ============ CALENDAR FUNCTIONS ============
  
  const getDaysInMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  const days = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

  // ============ RENDER CALENDAR GRID ============
  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentDate);
    const firstDay = getFirstDayOfMonth(currentDate);
    const days = [];

    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="aspect-square"></div>);
    }

    for (let i = 1; i <= daysInMonth; i++) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), i);
      const weton = getWeton(date);
      const wuku = getWuku(date);
      const neton = getNeton(date);
      const netonInfo = NETON_HASIL[neton];
      
      const isToday = new Date().toDateString() === date.toDateString();
      
      days.push(
        <div
          key={i}
          className={`aspect-square border rounded-lg p-2 text-xs cursor-pointer transition hover:shadow-md min-h-[110px] ${
            isToday ? 'bg-blue-100 border-blue-500' : 'bg-white border-gray-200 hover:bg-gray-50'
          }`}
          title={`${weton} - ${wuku} - Neton: ${neton} (${netonInfo.name})`}
        >
          <div className="font-bold text-sm mb-1">{i}</div>
          <div className="text-[10px] text-gray-600 mb-0.5">{weton.split(' ')[1]}</div>
          <div className="text-[9px] text-purple-600 font-semibold truncate">{wuku}</div>
          <div className={`text-[9px] font-bold ${netonInfo.type === 'bagus' ? 'text-green-600' : netonInfo.type === 'jelek' ? 'text-red-600' : 'text-orange-600'}`}>
            {neton}: {netonInfo.name.split('/')[0]}
          </div>
        </div>
      );
    }

    return days;
  };

  // ============ CALCULATOR TAB ============
  const calculateNeton = () => {
    const neptu = getNeptu(calculatorDate);
    const neton = getNeton(calculatorDate);
    const netonInfo = NETON_HASIL[neton];
    const weton = getWeton(calculatorDate);
    const wuku = getWuku(calculatorDate);

    return { neptu, neton, netonInfo, weton, wuku };
  };

  const calcResult = calculateNeton();

  // ============ RENDER ============
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 p-4">
      <div className="max-w-6xl mx-auto">
        
        {/* HEADER */}
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Calendar className="w-8 h-8 text-purple-600" />
            <h1 className="text-4xl font-bold text-purple-900">Kalender Jawa</h1>
          </div>
          <p className="text-gray-600">Pasaran, Wuku, Neptu & Neton Kalkulator</p>
          <p className="text-xs text-gray-500 mt-1">Blog referensi: arrjawa.blogspot.com</p>
        </div>

        {/* TABS */}
        <div className="flex gap-2 mb-6 justify-center flex-wrap">
          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition ${
              activeTab === 'calendar' ? 'bg-purple-600 text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Calendar className="w-5 h-5" /> Kalender
          </button>
          <button
            onClick={() => setActiveTab('calculator')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition ${
              activeTab === 'calculator' ? 'bg-purple-600 text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Calculator className="w-5 h-5" /> Kalkulator
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition ${
              activeTab === 'settings' ? 'bg-purple-600 text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Settings className="w-5 h-5" /> Sinkron
          </button>
        </div>

        {/* CALENDAR VIEW */}
        {activeTab === 'calendar' && (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <button onClick={prevMonth} className="p-2 hover:bg-gray-100 rounded-lg transition">
                <ChevronLeft className="w-6 h-6" />
              </button>
              <h2 className="text-2xl font-bold text-purple-900">
                {months[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h2>
              <button onClick={nextMonth} className="p-2 hover:bg-gray-100 rounded-lg transition">
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            <div className="grid grid-cols-7 gap-2 mb-2">
              {days.map(day => (
                <div key={day} className="aspect-square flex items-center justify-center font-bold text-gray-600">
                  {day}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-2">
              {renderCalendar()}
            </div>

            <div className="mt-6 pt-6 border-t border-gray-200">
              <h3 className="font-bold mb-3 text-gray-800">Keterangan Warna Neton:</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-green-600 rounded"></div>
                  <span className="text-sm">Bagus (Neton 2, 6)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-orange-600 rounded"></div>
                  <span className="text-sm">Sedang (Neton 3, 5)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-red-600 rounded"></div>
                  <span className="text-sm">Jelek (Neton 1, 4, 7)</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* CALCULATOR VIEW */}
        {activeTab === 'calculator' && (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-purple-900 mb-6">Kalkulator Neton</h2>
            
            <div className="mb-8">
              <label className="block text-sm font-semibold text-gray-700 mb-2">Pilih Tanggal:</label>
              <input
                type="date"
                value={calculatorDate.toISOString().split('T')[0]}
                onChange={(e) => setCalculatorDate(new Date(e.target.value))}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-purple-600 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <div className="space-y-4">
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg border-l-4 border-blue-600">
                  <p className="text-gray-600 text-sm mb-2">Weton (Hari + Pasaran)</p>
                  <p className="text-2xl font-bold text-blue-900">{calcResult.weton}</p>
                </div>

                <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-lg border-l-4 border-purple-600">
                  <p className="text-gray-600 text-sm mb-2">Wuku</p>
                  <p className="text-2xl font-bold text-purple-900">{calcResult.wuku}</p>
                </div>

                <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-lg border-l-4 border-orange-600">
                  <p className="text-gray-600 text-sm mb-2">Neptu (Nilai Angka)</p>
                  <p className="text-3xl font-bold text-orange-900">{calcResult.neptu}</p>
                  <p className="text-xs text-gray-600 mt-1">Dijumlah dari hari + pasaran</p>
                </div>
              </div>

              <div className={`p-8 rounded-lg border-2 ${
                calcResult.netonInfo.type === 'bagus' ? 'bg-green-50 border-green-400' :
                calcResult.netonInfo.type === 'jelek' ? 'bg-red-50 border-red-400' :
                'bg-orange-50 border-orange-400'
              }`}>
                <p className="text-gray-600 text-sm mb-2">Hasil Neton</p>
                <p className={`text-5xl font-bold mb-3 ${
                  calcResult.netonInfo.type === 'bagus' ? 'text-green-700' :
                  calcResult.netonInfo.type === 'jelek' ? 'text-red-700' :
                  'text-orange-700'
                }`}>
                  {calcResult.neton}
                </p>
                <p className="text-xl font-bold mb-2">{calcResult.netonInfo.name}</p>
                <p className="text-sm text-gray-700 mb-3">{calcResult.netonInfo.artinya}</p>
                <div className="flex items-start gap-2 text-xs bg-white bg-opacity-70 p-3 rounded mt-4">
                  <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <p>Rumus: (Neptu ÷ 7) sisa = Neton. Hasil 1-7 = Mati, Jodoh, Selamat, Cerai, Prihatin, Lancar, Pegat</p>
                </div>
              </div>
            </div>

            <div className="mt-8 overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-gray-100 border-b-2 border-gray-300">
                    <th className="px-4 py-3 text-left font-bold">Komponen</th>
                    <th className="px-4 py-3 text-left font-bold">Nilai</th>
                    <th className="px-4 py-3 text-left font-bold">Keterangan</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-4 py-3 font-semibold">Hari</td>
                    <td className="px-4 py-3">{NEPTU_HARI[calculatorDate.getDay()].name}</td>
                    <td className="px-4 py-3 text-gray-600">Neptu: {NEPTU_HARI[calculatorDate.getDay()].neptu}</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-4 py-3 font-semibold">Pasaran</td>
                    <td className="px-4 py-3">{getPasaran(calculatorDate)}</td>
                    <td className="px-4 py-3 text-gray-600">Neptu: {PASARAN_NEPTU[getPasaran(calculatorDate)]}</td>
                  </tr>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <td className="px-4 py-3 font-bold">Total Neptu</td>
                    <td className="px-4 py-3 font-bold text-lg">{calcResult.neptu}</td>
                    <td className="px-4 py-3 text-gray-600">{NEPTU_HARI[calculatorDate.getDay()].neptu} + {PASARAN_NEPTU[getPasaran(calculatorDate)]}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SETTINGS VIEW */}
        {activeTab === 'settings' && (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-purple-900 mb-6">Sinkron Google Calendar</h2>
            
            <div className="max-w-md">
              {!googleConnected ? (
                <div className="space-y-4">
                  <div className="bg-blue-50 border border-blue-200 p-6 rounded-lg">
                    <div className="flex items-start gap-4">
                      <Google className="w-8 h-8 text-blue-600 flex-shrink-0" />
                      <div>
                        <h3 className="font-bold text-gray-900 mb-2">Hubungkan Google Calendar</h3>
                        <p className="text-sm text-gray-600 mb-4">
                          Aplikasi akan mengakses kalender Anda untuk menampilkan agenda dan sinkron acara penting dengan kalender Jawa.
                        </p>
                        <button
                          onClick={() => setGoogleConnected(true)}
                          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition inline-flex items-center gap-2"
                        >
                          <Google className="w-4 h-4" />
                          Login dengan Google
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-200 p-6 rounded-lg">
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold">✓</div>
                      <div>
                        <h3 className="font-bold text-gray-900 mb-2">Terhubung!</h3>
                        <p className="text-sm text-gray-600 mb-4">
                          Akun Google Anda sudah terhubung. Aplikasi dapat membaca agenda dan menampilkan rekomendasi hari baik berdasarkan neton.
                        </p>
                        <button
                          onClick={() => setGoogleConnected(false)}
                          className="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition"
                        >
                          Disconnect
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h4 className="font-bold text-gray-900 mb-3">Fitur Terintegrasi:</h4>
                    <ul className="text-sm text-gray-700 space-y-2">
                      <li>✓ Tampilkan agenda dari Google Calendar</li>
                      <li>✓ Rekomendasi hari baik untuk event baru</li>
                      <li>✓ Notifikasi reminder dengan weton</li>
                      <li>✓ Export agenda ke kalender Jawa</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* FOOTER */}
        <div className="mt-12 text-center text-gray-600 text-sm pb-6">
          <p>Kalender Jawa v1.0 • Referensi: Blog arrjawa.blogspot.com</p>
          <p className="mt-2">Dikembangkan untuk dokumentasi tradisi kalender Jawa dengan teknologi modern</p>
        </div>
      </div>
    </div>
  );
};

export default CalendarJawaApp;
