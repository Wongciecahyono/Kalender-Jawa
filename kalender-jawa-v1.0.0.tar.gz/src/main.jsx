import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

// Capacitor initialization
import { App as CapApp } from '@capacitor/app';

CapApp.getInfo().then(info => {
  console.log(`Kalender Jawa v${info.version}`);
});

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
