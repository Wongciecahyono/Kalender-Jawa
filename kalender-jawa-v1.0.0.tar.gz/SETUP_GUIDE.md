# 📱 Kalender Jawa - Setup & Build Guide

## 🚀 Opsi Akses Cepat

### 1. **PALING MUDAH: Buka HTML langsung di Browser** ✅
```bash
# Buka file kalender-jawa.html di browser manapun
# - Desktop: Chrome, Firefox, Safari, Edge
# - Mobile: Buka dengan File Manager → tap kalender-jawa.html
```

**Keuntungan:**
- ✓ Tidak perlu install apapun
- ✓ Langsung bisa pakai semua fitur
- ✓ Bisa offline setelah dimuat sekali

---

## 📲 Opsi 2: Build ke APK Native (Android)

### Persyaratan:
- Node.js v16+ (https://nodejs.org)
- Android SDK (via Android Studio)
- Java Development Kit (JDK 11+)
- Git

### Langkah 1: Setup Project
```bash
# Clone/download project (atau ganti dengan path lokal)
mkdir kalender-jawa
cd kalender-jawa

# Copy file HTML ke sini
cp kalender-jawa.html ./

# Initialize npm project
npm init -y

# Install dependencies
npm install --save @capacitor/core @capacitor/cli
npm install --save-dev @capacitor/android @capacitor/ios

# Initialize Capacitor
npx cap init
# Jawab pertanyaan:
# - App name: Kalender Jawa
# - App Package: com.example.kalenderjawa
```

### Langkah 2: Setup Capacitor untuk Android
```bash
# Tambahkan platform Android
npx cap add android

# Build web assets
npx cap sync android
```

### Langkah 3: Setup Android Studio Integration
```bash
# Buka di Android Studio
npx cap open android

# Di Android Studio:
# 1. File → Project Structure → SDK Location
# 2. Pastikan Android SDK sudah terinstall
# 3. Connect device atau start emulator
# 4. Klik "Run" (play icon)
```

### Langkah 4: Build APK Release
```bash
# Build signed APK di Android Studio:
# 1. Build → Generate Signed Bundle / APK
# 2. Pilih "APK"
# 3. Create new keystore atau gunakan yang ada
# 4. Selesai! APK tersimpan di: android/app/release/app-release.apk
```

---

## 🌐 Opsi 3: Deploy ke Web (Gratis)

### Menggunakan Vercel (Recommended)
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel

# Ikuti instruksi, selesai! 🎉
```

**Hasil:** App bisa diakses dari URL seperti `https://kalender-jawa.vercel.app`

### Menggunakan GitHub Pages
```bash
# Buat folder docs/
mkdir docs
cp kalender-jawa.html docs/index.html

# Push ke GitHub
git add .
git commit -m "Add Kalender Jawa"
git push

# Di GitHub repo Settings:
# Pages → Source → main/docs → Save
```

---

## 🔧 Struktur Project (Untuk Development Lanjutan)

```
kalender-jawa/
├── kalender-jawa.html          # Main app (HTML+CSS+JS)
├── calendar-jawa-app.jsx        # React component version
├── package.json                 # Node dependencies
├── capacitor.config.json        # Capacitor config
├── android/                     # Android native code (auto-generated)
├── ios/                         # iOS native code (auto-generated)
└── SETUP_GUIDE.md              # File ini
```

---

## 🧮 Kalkulasi Jawa yang Diimplementasikan

### 1. **Pasaran** (5-hari siklus)
```
Legi   = Neptu 5
Pahing = Neptu 9
Pon    = Neptu 7
Wage   = Neptu 4
Kliwon = Neptu 8
```

### 2. **Hari** (7-hari siklus)
```
Ahad   = Neptu 5
Senen  = Neptu 4
Selasa = Neptu 3
Rabu   = Neptu 7
Kamis  = Neptu 8
Jumat  = Neptu 6
Sabtu  = Neptu 9
```

### 3. **Neptu** = Hari Neptu + Pasaran Neptu
```
Contoh: Jumat Kliwon
= 6 (Jumat) + 8 (Kliwon)
= 14
```

### 4. **Neton** = (Neptu mod 7)
```
Hasil 1-7:
1 = Mati (jelek)
2 = Jodoh (bagus)
3 = Selamat (sedang)
4 = Cerai (jelek)
5 = Prihatin (sedang)
6 = Lancar (bagus)
7 = Pegat (jelek)
```

### 5. **Wuku** (30-hari siklus)
```
30 wuku berputar dalam setahun Jawa (~354 hari)
Contoh: Sungsang, Langkir, Mangir, dll.
```

---

## 📚 Fitur Aplikasi

✅ **Sudah Aktif:**
- Kalender Jawa interaktif dengan warna neton
- Kalkulator pasaran + wuku + neptu + neton
- Tampilan month/detail tanggal
- Responsive (mobile & desktop)
- Offline-ready

⏳ **Fitur Lanjutan (Perlu Dikonfigurasi):**
- Google Calendar OAuth integration
- Sinkron agenda + rekomendasi hari baik
- Push notifications
- Export calendar

---

## 🐛 Testing Checklist

Sebelum deploy, test:

- [ ] Kalender bulan bisa navigasi (prev/next)
- [ ] Klik tanggal → weton, wuku, neton muncul
- [ ] Neptu dihitung benar
- [ ] Neton hasil 1-7 sesuai
- [ ] Warna neton sesuai (hijau=bagus, orange=sedang, merah=jelek)
- [ ] Responsive di mobile
- [ ] Bisa offline

---

## 📖 Referensi & Sumber

- **Blog Referensi:** arrjawa.blogspot.com
- **Rumus Primbon:** Kitab Primbon Jawa Kuno
- **Tech Stack:** HTML5 + Tailwind CSS + Vanilla JavaScript + Capacitor

---

## ❓ FAQ

**Q: Bisa di-update kalkulasi neton-nya?**
A: Ya! Edit bagian `NETON_HASIL` di dalam `<script>` tag untuk koreksi rumus/terjemahan.

**Q: Gimana cara add Google Calendar?**
A: Lihat section "Google Calendar Integration" di bawah.

**Q: Bisa di-publish ke Play Store?**
A: Ya, tapi perlu:
1. Signing key & release APK
2. Developer account Google Play (~$25)
3. App review (~1-2 hari)

**Q: Mau bikin iOS juga?**
A: Capacitor support iOS, tapi butuh Mac + Xcode.

---

## 🔐 Google Calendar Integration (Opsional)

Untuk production, setup:

1. **Google Cloud Console:**
   ```
   - Create project
   - Enable Google Calendar API
   - Create OAuth 2.0 credentials (Web application)
   - Copy Client ID
   ```

2. **Update kalender-jawa.html:**
   ```javascript
   const CLIENT_ID = 'YOUR_CLIENT_ID.apps.googleusercontent.com';
   
   // Add to connectGoogle() function:
   // gapi.auth2.getAuthInstance().signIn()
   // .then(() => loadCalendarEvents())
   ```

3. **Load gapi library di HTML:**
   ```html
   <script src="https://apis.google.com/js/api.js"></script>
   <script src="https://accounts.google.com/gsi/client"></script>
   ```

---

## 📞 Support & Koreksi

Kak Du, untuk koreksi/update rumus kalender:

1. Beri tahu di chat bagian mana yang salah
2. Saya update kode
3. Rebuild & deploy ulang

---

**Dibuat untuk: Kak Du, Blitar, East Java** 🇮🇩
